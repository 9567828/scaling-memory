package test;

public class MemberTest {

	public static void main(String[] args) {
		Member member = new Member("홍길동", "user01", 100);
		System.out.println(member.toString());
		
	}
}
